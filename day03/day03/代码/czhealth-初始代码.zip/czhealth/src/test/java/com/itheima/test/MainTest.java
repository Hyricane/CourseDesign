package com.itheima.test;

import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import org.springframework.util.DigestUtils;

public class MainTest {
    @Test
    public void testGetUsers() {
    }
}
